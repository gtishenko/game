self.__precacheManifest = [
  {
    "revision": "4474a5155866ea38e9cf",
    "url": "/static/css/main.106c245f.chunk.css"
  },
  {
    "revision": "4474a5155866ea38e9cf",
    "url": "/static/js/main.20e46b8a.chunk.js"
  },
  {
    "revision": "42ac5946195a7306e2a5",
    "url": "/static/js/runtime~main.a8a9905a.js"
  },
  {
    "revision": "b67f42bb4badf0d42328",
    "url": "/static/css/2.85c04939.chunk.css"
  },
  {
    "revision": "b67f42bb4badf0d42328",
    "url": "/static/js/2.4cc9385a.chunk.js"
  },
  {
    "revision": "d1b5f581678aac4f1a1c39b3f494cd91",
    "url": "/index.html"
  }
];